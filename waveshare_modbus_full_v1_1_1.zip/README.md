# Waveshare Modbus RTU for Home Assistant

Custom integration for Waveshare Modbus RTU Relay (V3), Modbus RTU Relay (D), Analog Output 8CH and Analog Input 8CH (standard/current and B/voltage variants).

## Important implementation notes

- One integration config entry represents one physical Waveshare module. The config flow probes the module (address, model) before adding it, and offers a second step for the A/B hardware variant on analog modules only.
- Multiple entries can share one serial port; the integration keeps one serial master per port and serializes transactions with a lock.
- All devices on a shared RS485 bus **must have the same baudrate, parity and stop bits**. Device address is individual and must be unique.
- Analog Input variant is selected per module: `current` = standard A hardware; `voltage` = B hardware. The same selector is used for Analog Output current/voltage variants.
- The hardware input jumper on Analog Input A/B must match the signal being measured. Software range changes cannot change the physical jumper.
- Changing UART settings on a shared bus changes the serial settings for the entire bus. The change runs under the bus lock: every module must answer first, each switch is confirmed afterwards, and on any failure everything is rolled back. It is refused while another entry on the same port is not loaded.
- Address changes (1-247) are sent to the old address, confirmed, and then the config entry (title and unique id) adopts the new address; an address already used by another entry on the same port is refused.

## Installation

1. Copy `custom_components/waveshare_modbus` to `/config/custom_components/waveshare_modbus`.
2. Restart Home Assistant.
3. Add **Waveshare Modbus RTU** under Settings → Devices & services.
4. Add each physical module as a separate integration entry. Use the same serial port and UART settings for modules on the same bus, but give each a unique slave address.

For USB RS485 adapters, prefer a stable path such as `/dev/serial/by-id/...` instead of `/dev/ttyUSB0`.

## Entities

### Relay V3
- 8 `switch` entities (FC01 polling; FC05 individual writes)
- Firmware, device address and baudrate diagnostic sensors
- Relay commands: on, off, toggle, flash-on and flash-off
- All-relay on/off (FC05 at 0x00FF); toggle-all at 0x01FF (V3, value 0xFF00) / 0x00FF (D, value 0x5500)
- Relay mask write and per-channel toggle mask (FC0F)

### Relay (D)
- 8 relay `switch` entities
- 8 digital input `binary_sensor` entities (FC02)
- 8 relay mode `select` entities (normal, linkage, toggle-on-pulse, edge-trigger)
- Relay control and flash commands
- Single and multiple relay mode writes (FC06/FC10)

### Analog Output 8CH
- 8 `number` entities and 8 output readback sensors (FC03)
- Current hardware: 0–20 mA (raw values in µA)
- B hardware: 0–10 V (raw values in mV)
- Individual output set (FC06) and batch output set (FC10)

### Analog Input 8CH
- 8 analog `sensor` entities (FC04)
- 8 range `select` entities (FC06)
- Range codes: 0 = 0–5 V / 0–10 V, 1 = 1–5 V / 2–10 V, 2 = 0–20 mA, 3 = 4–20 mA, 4 = raw ADC code
- Batch range write (FC10)
- The raw register value is exposed as `raw_value` attribute. Voltage/current modes are scaled from mV/µA to V/mA.

All device types expose firmware, address, baudrate and parity as diagnostic sensors (read once, refreshed after changes). Analog Input also has 8 raw-value sensors (disabled by default). Relay modules have per-relay toggle buttons. Polling interval is an option (Configure). A diagnostics download is available per entry.

## Services

All services require `entry_id`, available in the device's integration diagnostics/config entry.

- `waveshare_modbus.relay_command`: `command` = on/off/toggle/flash_on/flash_off; optional `channel` 1–8; optional `delay_units` (100 ms units, 1–32767).
- `waveshare_modbus.all_relays`: command = on/off/toggle.
- `waveshare_modbus.write_relay_mask`: mask 0–255, bit 0 = relay 1.
- `waveshare_modbus.toggle_relay_mask`: Relay V3 only; FC0F toggle register mask, bit 0 = relay 1.
- `waveshare_modbus.set_device_address`: address 1–247.
- `waveshare_modbus.set_communication`: baudrate 4800, 9600, 19200, 38400, 57600, 115200, 128000 or 256000; parity N/E/O.
- `waveshare_modbus.set_input_range`: channel 1–8, range 0–4.
- `waveshare_modbus.set_input_ranges`: eight range codes 0–4 (FC10).
- `waveshare_modbus.set_analog_output`: channel 1–8, raw value in µA or mV.
- `waveshare_modbus.set_analog_outputs`: eight raw output values (FC10).
- `waveshare_modbus.set_relay_mode`: channel 1–8, mode 0–3.
- `waveshare_modbus.set_relay_modes`: eight mode values 0–3 (FC10).

## Protocol coverage

Implemented RTU function codes used by the linked Waveshare protocol pages:

- FC01 read coils (relay state)
- FC02 read discrete inputs (Relay D DI)
- FC03 read holding registers (AO values, configuration, firmware, relay modes)
- FC04 read input registers (AI measurements)
- FC05 write single coil / Waveshare relay special commands (relay, all-relay, toggle, flash)
- FC06 write single register (AO value, AI range, Relay D mode, address, UART)
- FC0F write multiple coils (relay mask)
- FC10 write multiple registers (batch AO values, AI ranges, Relay D modes)

## Safety / limitations

- This is a community custom integration, not an official Waveshare or Home Assistant integration.
- The protocol layer is covered by `tests/test_protocol.py` (emulated slaves: framing, exceptions, address and UART change incl. rollback; run `python3 tests/test_protocol.py`). The Home Assistant layer was only import-checked and **nothing has been validated against physical hardware or a running Home Assistant** (needs HA 2024.11 or newer). Test with a non-critical relay/output first.
- Do not use relay outputs for safety-critical, life-support or emergency-stop functions.
- The Analog Input (B) board's voltage/current jumper configuration is physical. Select the correct hardware variant and set the board jumpers according to Waveshare instructions.
- The Waveshare Analog Input docs describe ADC-code mode as a linear conversion using board-specific amplifier and sampling resistor parameters. This integration exposes the raw ADC code for mode 4 rather than guessing the exact calibration constants for every hardware revision.
- The Waveshare Analog Output 8CH product page describes current output for the standard board and voltage output for the B variant. Maximums are constrained accordingly.
- If a device's serial settings are changed outside Home Assistant, update/reload the integration entries to match.

## Official references

- https://www.waveshare.com/wiki/Modbus_RTU_Relay
- https://www.waveshare.com/wiki/Modbus_RTU_Relay_%28D%29
- https://www.waveshare.com/wiki/Modbus_RTU_Analog_Output_8CH
- https://www.waveshare.com/wiki/Modbus_RTU_Analog_Input_8CH
- https://www.waveshare.com/wiki/Modbus_RTU_Analog_Input_8CH_%28B%29

## Values to verify against the Waveshare wiki

Toggle addresses/values (V3: 0x0100+ch / 0xFF00, D: 0x5500), the Relay (D) mode register 0x1000, the UART register 0x2000 and whether UART/address changes apply immediately or only after a power cycle. Entity names are English; error and config texts have en and nl translations.
