from homeassistant.components.sensor import SensorDeviceClass, SensorEntity, SensorStateClass
from homeassistant.const import EntityCategory

from .const import DOMAIN
from .entity import WaveshareEntity
from .protocol import analog_input


async def async_setup_entry(hass, entry, async_add_entities):
    c = hass.data[DOMAIN]["coordinators"][entry.entry_id]
    entities = [WaveshareDiagnostic(c, "firmware", "Firmware"),
                WaveshareDiagnostic(c, "device_address", "Modbus address (device)"),
                WaveshareDiagnostic(c, "baudrate", "Baudrate (device)"),
                WaveshareDiagnostic(c, "parity", "Parity (device)")]
    if c.model == "analog_input":
        entities += [WaveshareAnalogInput(c, i) for i in range(8)]
        entities += [WaveshareAnalogRaw(c, i) for i in range(8)]
    if c.model == "analog_output":
        entities += [WaveshareAnalogOutputReadback(c, i) for i in range(8)]
    async_add_entities(entities)


class WaveshareDiagnostic(WaveshareEntity, SensorEntity):
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, c, key, name):
        super().__init__(c)
        self.key = key
        self._attr_name = name
        self._attr_unique_id = f"{c.entry.entry_id}_{key}"

    @property
    def native_value(self):
        return self.coordinator.data.get(self.key)


class WaveshareAnalogInput(WaveshareEntity, SensorEntity):
    """Scaled value: V or mA depending on the configured range; ADC code in range 4.

    The unit follows the range select, so changing the range of a channel changes
    the unit (Home Assistant then offers to fix long-term statistics).
    """
    _attr_state_class = SensorStateClass.MEASUREMENT
    _attr_suggested_display_precision = 3

    def __init__(self, c, ch):
        super().__init__(c, ch)
        self._attr_name = f"Analog input {ch + 1}"
        self._attr_unique_id = f"{c.entry.entry_id}_ai_{ch + 1}"

    @property
    def _mode(self):
        return self.coordinator.data["input_ranges"][self.channel]

    @property
    def native_value(self):
        return analog_input.scale(self.coordinator.data["inputs_raw"][self.channel], self._mode)

    @property
    def device_class(self):
        return {0: SensorDeviceClass.VOLTAGE, 1: SensorDeviceClass.VOLTAGE,
                2: SensorDeviceClass.CURRENT, 3: SensorDeviceClass.CURRENT}.get(self._mode)

    @property
    def native_unit_of_measurement(self):
        return {0: "V", 1: "V", 2: "mA", 3: "mA"}.get(self._mode)

    @property
    def extra_state_attributes(self):
        labels = analog_input.RANGES[self.coordinator.variant]
        return {"raw_value": self.coordinator.data["inputs_raw"][self.channel],
                "range_code": self._mode, "range": labels.get(self._mode)}


class WaveshareAnalogRaw(WaveshareEntity, SensorEntity):
    """Raw register value (mV / µA / ADC code); disabled by default."""
    _attr_entity_registry_enabled_default = False
    _attr_entity_category = EntityCategory.DIAGNOSTIC
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(self, c, ch):
        super().__init__(c, ch)
        self._attr_name = f"Analog input {ch + 1} raw"
        self._attr_unique_id = f"{c.entry.entry_id}_ai_raw_{ch + 1}"

    @property
    def native_value(self):
        return self.coordinator.data["inputs_raw"][self.channel]


class WaveshareAnalogOutputReadback(WaveshareEntity, SensorEntity):
    _attr_state_class = SensorStateClass.MEASUREMENT
    _attr_suggested_display_precision = 3

    def __init__(self, c, ch):
        super().__init__(c, ch)
        voltage = c.variant == "voltage"
        self._attr_name = f"Analog output {ch + 1} readback"
        self._attr_unique_id = f"{c.entry.entry_id}_ao_read_{ch + 1}"
        self._attr_native_unit_of_measurement = "V" if voltage else "mA"
        self._attr_device_class = SensorDeviceClass.VOLTAGE if voltage else SensorDeviceClass.CURRENT

    @property
    def native_value(self):
        return self.coordinator.data["outputs"][self.channel] / 1000
