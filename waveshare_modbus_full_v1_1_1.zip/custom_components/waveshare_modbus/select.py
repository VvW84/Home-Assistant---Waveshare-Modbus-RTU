from homeassistant.components.select import SelectEntity
from homeassistant.const import EntityCategory

from .const import BAUDRATES, DOMAIN
from .entity import WaveshareEntity
from .hub import async_change_bus_uart
from .protocol import analog_input, relay_d


async def async_setup_entry(hass, entry, async_add_entities):
    c = hass.data[DOMAIN]["coordinators"][entry.entry_id]
    entities = [WaveshareBusSetting(c, "baudrate"), WaveshareBusSetting(c, "parity")]
    if c.model == "analog_input":
        entities += [WaveshareCodeSelect(c, i, analog_input.RANGES[c.variant], "input_ranges",
                                         "set_range", f"Input {i + 1} range", f"range_{i + 1}")
                     for i in range(8)]
    if c.model == "relay_d":
        entities += [WaveshareCodeSelect(c, i, relay_d.MODES, "relay_modes", "set_mode",
                                         f"Relay {i + 1} control mode", f"mode_{i + 1}")
                     for i in range(8)]
    async_add_entities(entities)


class WaveshareCodeSelect(WaveshareEntity, SelectEntity):
    """Per-channel select backed by a numeric code (input range / relay mode)."""
    _attr_entity_category = EntityCategory.CONFIG

    def __init__(self, c, ch, codes, data_key, setter, name, uid):
        super().__init__(c, ch)
        self._codes, self._key, self._setter = codes, data_key, setter
        self._attr_name = name
        self._attr_unique_id = f"{c.entry.entry_id}_{uid}"
        self._attr_options = list(codes.values())

    @property
    def current_option(self):
        return self._codes.get(self.coordinator.data[self._key][self.channel])

    async def async_select_option(self, option):
        code = next(k for k, v in self._codes.items() if v == option)
        await self.coordinator.async_run(self._setter, self.channel, code)


class WaveshareBusSetting(WaveshareEntity, SelectEntity):
    """Bus-wide UART setting: changing it re-configures every module on this RS485 bus."""
    _attr_entity_category = EntityCategory.CONFIG

    def __init__(self, c, key):
        super().__init__(c)
        self.key = key
        self._attr_name = "Bus baudrate" if key == "baudrate" else "Bus parity"
        self._attr_unique_id = f"{c.entry.entry_id}_bus_{key}"
        self._attr_options = [str(v) for v in BAUDRATES] if key == "baudrate" else ["N", "E", "O"]

    @property
    def current_option(self):
        client = self.coordinator.hub.client
        return str(client.baudrate if self.key == "baudrate" else client.parity)

    async def async_select_option(self, option):
        client = self.coordinator.hub.client
        baud = int(option) if self.key == "baudrate" else client.baudrate
        parity = option if self.key == "parity" else client.parity
        await async_change_bus_uart(self.hass, self.coordinator.hub, baud, parity)
        self.async_write_ha_state()
