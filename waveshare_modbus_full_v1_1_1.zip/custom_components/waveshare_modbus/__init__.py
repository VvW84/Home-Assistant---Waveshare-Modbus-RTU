from __future__ import annotations

import voluptuous as vol

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.exceptions import ConfigEntryError, ConfigEntryNotReady

from .const import (BAUDRATES, CONF_BAUDRATE, CONF_PARITY, CONF_PORT, CONF_STOPBITS,
                    DOMAIN, MAX_ADDRESS, PLATFORMS)
from .coordinator import WaveshareCoordinator, ha_error, scan_interval
from .hub import WaveshareHub, async_change_bus_uart
from .protocol.rtu import ModbusError

SERVICES_REGISTERED = "services_registered"


def _state(hass: HomeAssistant) -> dict:
    return hass.data.setdefault(DOMAIN, {"hubs": {}, "coordinators": {}})


async def async_setup(hass: HomeAssistant, config: dict) -> bool:
    _state(hass)
    return True


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    state = _state(hass)
    data = entry.data
    wanted = (data[CONF_BAUDRATE], data[CONF_PARITY], data[CONF_STOPBITS])
    hub = state["hubs"].get(data[CONF_PORT])
    created = hub is None
    if created:
        hub = WaveshareHub(data[CONF_PORT], *wanted)
        state["hubs"][hub.port] = hub
    elif hub.settings != wanted:
        raise ConfigEntryError(translation_domain=DOMAIN, translation_key="bus_conflict",
                               translation_placeholders={"port": hub.port})
    try:
        try:
            await hass.async_add_executor_job(hub.client.open)
        except ModbusError as err:
            raise ConfigEntryNotReady(f"Cannot open serial port: {err}") from err
        coordinator = WaveshareCoordinator(hass, hub, entry)
        await coordinator.async_config_entry_first_refresh()
    except BaseException:
        if created or not hub.entry_ids:
            await hass.async_add_executor_job(hub.close)
            state["hubs"].pop(hub.port, None)
        raise
    hub.entry_ids.add(entry.entry_id)
    state["coordinators"][entry.entry_id] = coordinator
    entry.async_on_unload(entry.add_update_listener(_options_updated))
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    if not state.get(SERVICES_REGISTERED):
        _register_services(hass)
        state[SERVICES_REGISTERED] = True
    return True


async def _options_updated(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Apply a changed polling interval without reloading (address/UART updates also land here)."""
    coordinator = _state(hass)["coordinators"].get(entry.entry_id)
    if coordinator is not None:
        coordinator.update_interval = scan_interval(entry)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    if not await hass.config_entries.async_unload_platforms(entry, PLATFORMS):
        return False
    state = _state(hass)
    coordinator = state["coordinators"].pop(entry.entry_id, None)
    if coordinator:
        hub = coordinator.hub
        hub.entry_ids.discard(entry.entry_id)
        if not hub.entry_ids:
            await hass.async_add_executor_job(hub.close)
            state["hubs"].pop(hub.port, None)
    if not state["coordinators"] and state.get(SERVICES_REGISTERED):
        for service in list(hass.services.async_services_for_domain(DOMAIN)):
            hass.services.async_remove(DOMAIN, service)
        state[SERVICES_REGISTERED] = False
    return True


def _register_services(hass: HomeAssistant) -> None:
    def coordinator_for(call: ServiceCall) -> WaveshareCoordinator:
        c = _state(hass)["coordinators"].get(call.data["entry_id"])
        if c is None:
            raise ha_error("unknown_entry")
        return c

    eid = {vol.Required("entry_id"): str}
    channel = {vol.Required("channel"): vol.All(int, vol.Range(min=1, max=8))}
    eight = vol.All([int], vol.Length(min=8, max=8))
    mask = {vol.Required("mask"): vol.All(int, vol.Range(min=0, max=255))}

    async def relay_command(call):
        c = coordinator_for(call)
        ch, cmd = call.data["channel"] - 1, call.data["command"]
        delay = call.data["delay_units"]
        if cmd in ("on", "off"):
            await c.async_run("set_relay", ch, cmd == "on")
        elif cmd == "toggle":
            await c.async_run("toggle", ch)
        else:
            await c.async_run("flash", ch, cmd == "flash_on", delay)

    async def all_relays(call):
        await coordinator_for(call).async_run("all_relays", call.data["command"])

    async def write_relay_mask(call):
        await coordinator_for(call).async_run("write_mask", call.data["mask"])

    async def toggle_relay_mask(call):
        await coordinator_for(call).async_run("toggle_mask", call.data["mask"])

    async def set_device_address(call):
        await coordinator_for(call).async_set_address(call.data["address"])

    async def set_communication(call):
        c = coordinator_for(call)
        await async_change_bus_uart(hass, c.hub, call.data["baudrate"], call.data["parity"])

    async def set_input_range(call):
        await coordinator_for(call).async_run("set_range", call.data["channel"] - 1, call.data["range"])

    async def set_input_ranges(call):
        await coordinator_for(call).async_run("set_ranges", call.data["values"])

    async def set_analog_output(call):
        c = coordinator_for(call)
        await c.async_run("set_output", call.data["channel"] - 1, call.data["value"], c.variant)

    async def set_analog_outputs(call):
        c = coordinator_for(call)
        await c.async_run("set_outputs", call.data["values"], c.variant)

    async def set_relay_mode(call):
        await coordinator_for(call).async_run("set_mode", call.data["channel"] - 1, call.data["mode"])

    async def set_relay_modes(call):
        await coordinator_for(call).async_run("set_modes", call.data["values"])

    def reg(name, handler, fields):
        hass.services.async_register(DOMAIN, name, handler, schema=vol.Schema({**eid, **fields}))

    reg("relay_command", relay_command, {
        vol.Required("command"): vol.In(["on", "off", "toggle", "flash_on", "flash_off"]),
        vol.Optional("channel", default=1): vol.All(int, vol.Range(min=1, max=8)),
        vol.Optional("delay_units", default=7): vol.All(int, vol.Range(min=1, max=32767))})
    reg("all_relays", all_relays, {vol.Required("command"): vol.In(["on", "off", "toggle"])})
    reg("write_relay_mask", write_relay_mask, mask)
    reg("toggle_relay_mask", toggle_relay_mask, mask)
    reg("set_device_address", set_device_address,
        {vol.Required("address"): vol.All(int, vol.Range(min=1, max=MAX_ADDRESS))})
    reg("set_communication", set_communication, {
        vol.Required("baudrate"): vol.In(BAUDRATES), vol.Required("parity"): vol.In(["N", "E", "O"])})
    reg("set_input_range", set_input_range,
        {**channel, vol.Required("range"): vol.All(int, vol.Range(min=0, max=4))})
    reg("set_input_ranges", set_input_ranges, {vol.Required("values"): eight})
    reg("set_analog_output", set_analog_output,
        {**channel, vol.Required("value"): vol.All(int, vol.Range(min=0, max=20000))})
    reg("set_analog_outputs", set_analog_outputs, {vol.Required("values"): eight})
    reg("set_relay_mode", set_relay_mode,
        {**channel, vol.Required("mode"): vol.All(int, vol.Range(min=0, max=3))})
    reg("set_relay_modes", set_relay_modes, {vol.Required("values"): eight})
