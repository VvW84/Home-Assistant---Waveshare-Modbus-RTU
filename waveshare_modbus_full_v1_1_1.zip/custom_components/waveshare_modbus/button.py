from homeassistant.components.button import ButtonEntity
from homeassistant.const import EntityCategory

from .const import DOMAIN, RELAY_MODELS
from .entity import WaveshareEntity


async def async_setup_entry(hass, entry, async_add_entities):
    c = hass.data[DOMAIN]["coordinators"][entry.entry_id]
    entities = [WaveshareRefreshButton(c)]
    if c.model in RELAY_MODELS:
        entities += [WaveshareToggleButton(c, i) for i in range(8)]
    async_add_entities(entities)


class WaveshareRefreshButton(WaveshareEntity, ButtonEntity):
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, c):
        super().__init__(c)
        self._attr_name = "Refresh device"
        self._attr_unique_id = f"{c.entry.entry_id}_refresh"

    async def async_press(self):
        await self.coordinator.async_request_refresh()


class WaveshareToggleButton(WaveshareEntity, ButtonEntity):
    def __init__(self, c, ch):
        super().__init__(c, ch)
        self._attr_name = f"Toggle relay {ch + 1}"
        self._attr_unique_id = f"{c.entry.entry_id}_toggle_{ch + 1}"

    async def async_press(self):
        await self.coordinator.async_run("toggle", self.channel)
