from homeassistant.components.binary_sensor import BinarySensorEntity

from .const import DOMAIN
from .entity import WaveshareEntity


async def async_setup_entry(hass, entry, async_add_entities):
    c = hass.data[DOMAIN]["coordinators"][entry.entry_id]
    if c.model == "relay_d":
        async_add_entities([WaveshareDI(c, i) for i in range(8)])


class WaveshareDI(WaveshareEntity, BinarySensorEntity):
    def __init__(self, c, ch):
        super().__init__(c, ch)
        self._attr_name = f"Digital input {ch + 1}"
        self._attr_unique_id = f"{c.entry.entry_id}_di_{ch + 1}"

    @property
    def is_on(self):
        return self.coordinator.data["inputs"][self.channel]
