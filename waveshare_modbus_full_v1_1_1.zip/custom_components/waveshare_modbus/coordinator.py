from __future__ import annotations

import logging
import re
from datetime import timedelta

from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import (CONF_MODEL, CONF_PORT, CONF_SCAN_INTERVAL, CONF_SLAVE, CONF_VARIANT,
                    DEFAULT_SCAN_INTERVAL, DOMAIN, MODELS)
from .protocol import PROTOCOLS, common
from .protocol.rtu import ModbusError

_LOGGER = logging.getLogger(__name__)
MAX_TOLERATED_FAILURES = 2  # consecutive failed polls before entities become unavailable


def scan_interval(entry) -> timedelta:
    seconds = entry.options.get(CONF_SCAN_INTERVAL, entry.data.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL))
    return timedelta(seconds=seconds)


def ha_error(key: str, **placeholders) -> HomeAssistantError:
    return HomeAssistantError(translation_domain=DOMAIN, translation_key=key,
                              translation_placeholders={k: str(v) for k, v in placeholders.items()})


class WaveshareCoordinator(DataUpdateCoordinator):
    def __init__(self, hass: HomeAssistant, hub, entry):
        self.hub = hub
        self.entry = entry
        self.model = entry.data[CONF_MODEL]
        self.variant = entry.data.get(CONF_VARIANT, "current")
        self.slave = entry.data[CONF_SLAVE]
        self.proto = PROTOCOLS[self.model]
        self._failures = 0
        self.info: dict = {}  # static data (address, firmware, UART): read once
        super().__init__(hass, _LOGGER, config_entry=entry, name=f"Waveshare {entry.title}",
                         update_interval=scan_interval(entry))

    def mark_info_stale(self):
        self.info = {}

    def _poll(self):
        if not self.info:
            self.info = common.read_info(self.hub.client, self.slave)
        data = self.proto.refresh(self.hub.client, self.slave, self.variant)
        data.update(self.info)
        return data

    async def _async_update_data(self):
        try:
            data = await self.hass.async_add_executor_job(self._poll)
        except (ModbusError, ValueError) as err:
            self._failures += 1
            if self.data is not None and self._failures <= MAX_TOLERATED_FAILURES:
                _LOGGER.debug("Poll of %s failed (%d/%d), keeping last values: %s",
                              self.name, self._failures, MAX_TOLERATED_FAILURES, err)
                return self.data
            raise UpdateFailed(f"Modbus read failed: {err}") from err
        self._failures = 0
        return data

    def func(self, name: str):
        """Protocol function for this model, or a translated 'wrong model' error."""
        function = getattr(self.proto, name, None)
        if function is None:
            raise ha_error("wrong_model", model=MODELS[self.model])
        return function

    async def async_run(self, func, *args, refresh: bool = True):
        """Run a protocol function (client, slave, *args) with translated errors."""
        if isinstance(func, str):
            func = self.func(func)
        try:
            result = await self.hass.async_add_executor_job(func, self.hub.client, self.slave, *args)
        except ValueError as err:
            raise ha_error("invalid_value", error=err) from err
        except ModbusError as err:
            raise ha_error("modbus_error", error=err) from err
        if refresh:
            await self.async_request_refresh()
        return result

    async def async_set_address(self, new: int):
        new = int(new)
        if not 1 <= new <= common.MAX_ADDRESS:
            raise ha_error("invalid_value", error=f"address must be 1..{common.MAX_ADDRESS}")
        port = self.entry.data[CONF_PORT]
        for other in self.hass.config_entries.async_entries(DOMAIN):
            if other.entry_id != self.entry.entry_id and other.data[CONF_PORT] == port \
                    and other.data[CONF_SLAVE] == new:
                raise ha_error("address_in_use", address=new)
        await self.async_run(common.set_address, new, refresh=False)
        title = re.sub(r"\(ID \d+\)$", f"(ID {new})", self.entry.title)
        self.hass.config_entries.async_update_entry(
            self.entry, data={**self.entry.data, CONF_SLAVE: new}, title=title,
            unique_id=f"{port}-{new}")
        self.slave = new
        self.mark_info_stale()
        await self.async_request_refresh()
