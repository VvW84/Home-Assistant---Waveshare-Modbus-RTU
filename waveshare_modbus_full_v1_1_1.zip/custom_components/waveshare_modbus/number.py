from homeassistant.components.number import NumberDeviceClass, NumberEntity, NumberMode
from homeassistant.const import EntityCategory

from .const import DOMAIN, MAX_ADDRESS
from .entity import WaveshareEntity
from .protocol import analog_output


async def async_setup_entry(hass, entry, async_add_entities):
    c = hass.data[DOMAIN]["coordinators"][entry.entry_id]
    entities = [WaveshareAddressNumber(c)]
    if c.model == "analog_output":
        entities += [WaveshareAOSetpoint(c, i) for i in range(8)]
    async_add_entities(entities)


class WaveshareAOSetpoint(WaveshareEntity, NumberEntity):
    _attr_mode = NumberMode.BOX
    _attr_native_step = 0.001
    _attr_native_min_value = 0

    def __init__(self, c, ch):
        super().__init__(c, ch)
        voltage = c.variant == "voltage"
        self._attr_name = f"Analog output {ch + 1}"
        self._attr_unique_id = f"{c.entry.entry_id}_ao_{ch + 1}"
        self._attr_native_max_value = 10 if voltage else 20
        self._attr_native_unit_of_measurement = "V" if voltage else "mA"
        self._attr_device_class = NumberDeviceClass.VOLTAGE if voltage else NumberDeviceClass.CURRENT

    @property
    def native_value(self):
        return self.coordinator.data["outputs"][self.channel] / 1000

    async def async_set_native_value(self, value):
        c = self.coordinator
        await c.async_run(analog_output.set_output, self.channel, round(value * 1000), c.variant)


class WaveshareAddressNumber(WaveshareEntity, NumberEntity):
    _attr_entity_category = EntityCategory.CONFIG
    _attr_mode = NumberMode.BOX
    _attr_native_min_value = 1
    _attr_native_max_value = MAX_ADDRESS
    _attr_native_step = 1

    def __init__(self, c):
        super().__init__(c)
        self._attr_name = "Modbus address"
        self._attr_unique_id = f"{c.entry.entry_id}_address"

    @property
    def native_value(self):
        return self.coordinator.data.get("device_address", self.coordinator.slave)

    async def async_set_native_value(self, value):
        await self.coordinator.async_set_address(int(value))
