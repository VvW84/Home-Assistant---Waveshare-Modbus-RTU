from __future__ import annotations

from homeassistant.components.diagnostics import async_redact_data
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from .const import DOMAIN

TO_REDACT = {"name"}


async def async_get_config_entry_diagnostics(hass: HomeAssistant, entry: ConfigEntry) -> dict:
    c = hass.data[DOMAIN]["coordinators"].get(entry.entry_id)
    out = {"entry": async_redact_data(dict(entry.data), TO_REDACT), "options": dict(entry.options)}
    if c is not None:
        client = c.hub.client
        out.update({
            "model": c.model, "variant": c.variant, "slave": c.slave,
            "bus": {"port": c.hub.port, "baudrate": client.baudrate, "parity": client.parity,
                    "stopbits": client.stopbits, "port_open": bool(client.serial and client.serial.is_open),
                    "modules_on_bus": len(c.hub.entry_ids)},
            "last_update_success": c.last_update_success,
            "last_exception": repr(c.last_exception) if c.last_exception else None,
            "update_interval_s": c.update_interval.total_seconds() if c.update_interval else None,
            "data": c.data,
        })
    return out
