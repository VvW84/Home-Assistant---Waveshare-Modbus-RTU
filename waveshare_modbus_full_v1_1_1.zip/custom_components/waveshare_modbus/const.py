from homeassistant.const import Platform

from .protocol.common import BAUDRATES, MAX_ADDRESS, PARITIES  # noqa: F401

DOMAIN = "waveshare_modbus"
PLATFORMS = [Platform.SWITCH, Platform.BINARY_SENSOR, Platform.SENSOR,
             Platform.NUMBER, Platform.SELECT, Platform.BUTTON]
CONF_PORT = "port"
CONF_SLAVE = "slave"
CONF_MODEL = "model"
CONF_VARIANT = "variant"
CONF_BAUDRATE = "baudrate"
CONF_PARITY = "parity"
CONF_STOPBITS = "stopbits"
CONF_SCAN_INTERVAL = "scan_interval"
DEFAULT_SCAN_INTERVAL = 5
MODELS = {
    "relay": "Modbus RTU Relay (V3)",
    "relay_d": "Modbus RTU Relay (D)",
    "analog_output": "Modbus RTU Analog Output 8CH",
    "analog_input": "Modbus RTU Analog Input 8CH",
}
ANALOG_MODELS = ("analog_output", "analog_input")
RELAY_MODELS = ("relay", "relay_d")
VARIANTS = {"current": "Current / standard (A)", "voltage": "Voltage (B)"}
