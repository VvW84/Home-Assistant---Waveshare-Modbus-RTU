from homeassistant.components.switch import SwitchEntity

from .const import DOMAIN, RELAY_MODELS
from .entity import WaveshareEntity


async def async_setup_entry(hass, entry, async_add_entities):
    c = hass.data[DOMAIN]["coordinators"][entry.entry_id]
    if c.model in RELAY_MODELS:
        async_add_entities([WaveshareRelaySwitch(c, i) for i in range(8)])


class WaveshareRelaySwitch(WaveshareEntity, SwitchEntity):
    def __init__(self, c, ch):
        super().__init__(c, ch)
        self._attr_name = f"Relay {ch + 1}"
        self._attr_unique_id = f"{c.entry.entry_id}_relay_{ch + 1}"

    @property
    def is_on(self):
        return self.coordinator.data["relay"][self.channel]

    async def async_turn_on(self, **kwargs):
        await self.coordinator.async_run("set_relay", self.channel, True)

    async def async_turn_off(self, **kwargs):
        await self.coordinator.async_run("set_relay", self.channel, False)
