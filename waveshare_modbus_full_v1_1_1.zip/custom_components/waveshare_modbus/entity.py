from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN, MODELS


class WaveshareEntity(CoordinatorEntity):
    _attr_has_entity_name = True

    def __init__(self, coordinator, channel=None):
        super().__init__(coordinator)
        self.channel = channel
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, coordinator.entry.entry_id)},
            name=coordinator.entry.title,
            manufacturer="Waveshare",
            model=MODELS[coordinator.model],
            sw_version=coordinator.info.get("firmware"),
        )
