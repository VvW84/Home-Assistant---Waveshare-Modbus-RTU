from __future__ import annotations

import voluptuous as vol

from homeassistant import config_entries
from homeassistant.const import CONF_NAME
from homeassistant.core import callback

from .const import (ANALOG_MODELS, BAUDRATES, CONF_BAUDRATE, CONF_MODEL, CONF_PARITY, CONF_PORT,
                    CONF_SCAN_INTERVAL, CONF_SLAVE, CONF_STOPBITS, CONF_VARIANT,
                    DEFAULT_SCAN_INTERVAL, DOMAIN, MAX_ADDRESS, MODELS, VARIANTS)
from .protocol import PROTOCOLS, common
from .protocol.rtu import ModbusError, RTUClient

SCAN = vol.All(int, vol.Range(min=1, max=300))


def _probe(client: RTUClient, slave: int, model: str, temporary: bool) -> str | None:
    """Return an error key, or None when the module answers like the chosen model."""
    try:
        try:
            common.read_info(client, slave)
        except ModbusError:
            return "cannot_connect"
        try:
            PROTOCOLS[model].refresh(client, slave, "current")
        except ModbusError:
            return "wrong_model"
        return None
    finally:
        if temporary:
            client.close()


class WaveshareConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    VERSION = 1

    def __init__(self):
        self._data: dict = {}

    async def _async_test(self, data) -> str | None:
        hub = self.hass.data.get(DOMAIN, {}).get("hubs", {}).get(data[CONF_PORT])
        wanted = (data[CONF_BAUDRATE], data[CONF_PARITY], data[CONF_STOPBITS])
        if hub is not None:
            if hub.settings != wanted:
                return "bus_mismatch"
            client, temporary = hub.client, False
        else:
            client, temporary = RTUClient(data[CONF_PORT], *wanted), True
        return await self.hass.async_add_executor_job(
            _probe, client, data[CONF_SLAVE], data[CONF_MODEL], temporary)

    async def async_step_user(self, user_input=None):
        errors = {}
        if user_input is not None:
            await self.async_set_unique_id(f"{user_input[CONF_PORT]}-{user_input[CONF_SLAVE]}")
            self._abort_if_unique_id_configured()
            error = await self._async_test(user_input)
            if error is None:
                self._data = dict(user_input)
                if user_input[CONF_MODEL] in ANALOG_MODELS:
                    return await self.async_step_variant()
                return self._create({CONF_VARIANT: "current"})
            errors["base"] = error
        d = user_input or {}
        schema = vol.Schema({
            vol.Required(CONF_NAME, default=d.get(CONF_NAME, "Waveshare module")): str,
            vol.Required(CONF_PORT, default=d.get(CONF_PORT, "/dev/serial/by-id/your-rs485-adapter")): str,
            vol.Required(CONF_SLAVE, default=d.get(CONF_SLAVE, 1)): vol.All(int, vol.Range(min=1, max=MAX_ADDRESS)),
            vol.Required(CONF_MODEL, default=d.get(CONF_MODEL, "relay")): vol.In(MODELS),
            vol.Required(CONF_BAUDRATE, default=d.get(CONF_BAUDRATE, 9600)): vol.In(BAUDRATES),
            vol.Required(CONF_PARITY, default=d.get(CONF_PARITY, "N")): vol.In(["N", "E", "O"]),
            vol.Required(CONF_STOPBITS, default=d.get(CONF_STOPBITS, 1)): vol.In([1, 2]),
            vol.Required(CONF_SCAN_INTERVAL, default=d.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL)): SCAN,
        })
        return self.async_show_form(step_id="user", data_schema=schema, errors=errors)

    async def async_step_variant(self, user_input=None):
        if user_input is not None:
            return self._create(user_input)
        return self.async_show_form(step_id="variant", data_schema=vol.Schema(
            {vol.Required(CONF_VARIANT, default="current"): vol.In(VARIANTS)}))

    def _create(self, extra):
        data = {**self._data, **extra}
        title = f"{data[CONF_NAME]} – {MODELS[data[CONF_MODEL]]} (ID {data[CONF_SLAVE]})"
        return self.async_create_entry(title=title, data=data)

    @staticmethod
    @callback
    def async_get_options_flow(config_entry):
        return WaveshareOptionsFlow()


class WaveshareOptionsFlow(config_entries.OptionsFlow):
    async def async_step_init(self, user_input=None):
        if user_input is not None:
            return self.async_create_entry(data=user_input)
        current = self.config_entry.options.get(
            CONF_SCAN_INTERVAL, self.config_entry.data.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL))
        return self.async_show_form(step_id="init", data_schema=vol.Schema(
            {vol.Required(CONF_SCAN_INTERVAL, default=current): SCAN}))
