"""One shared serial master per physical RS485 port."""
from __future__ import annotations

import logging

from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError

from .const import CONF_BAUDRATE, CONF_PARITY, CONF_PORT, DOMAIN
from .protocol import common
from .protocol.rtu import ModbusError, RTUClient

_LOGGER = logging.getLogger(__name__)


class WaveshareHub:
    def __init__(self, port, baudrate, parity, stopbits):
        self.port = port
        self.client = RTUClient(port, baudrate, parity, stopbits)
        self.entry_ids: set[str] = set()

    @property
    def settings(self):
        c = self.client
        return (c.baudrate, c.parity, c.stopbits)

    def close(self):
        self.client.close()

    def set_uart_for_devices(self, slaves, baudrate, parity):
        common.set_uart_for_devices(self.client, slaves, baudrate, parity)


async def async_change_bus_uart(hass: HomeAssistant, hub: WaveshareHub, baudrate: int, parity: str):
    """Change UART settings for every module on this bus (all-or-nothing)."""
    state = hass.data[DOMAIN]
    entries = [e for e in hass.config_entries.async_entries(DOMAIN) if e.data[CONF_PORT] == hub.port]
    missing = [e.title for e in entries if e.entry_id not in state["coordinators"]]
    if missing:
        raise HomeAssistantError(translation_domain=DOMAIN, translation_key="bus_entries_not_loaded",
                                 translation_placeholders={"entries": ", ".join(missing)})
    slaves = [state["coordinators"][e.entry_id].slave for e in entries]
    try:
        await hass.async_add_executor_job(hub.set_uart_for_devices, slaves, baudrate, parity)
    except ValueError as err:
        raise HomeAssistantError(translation_domain=DOMAIN, translation_key="invalid_value",
                                 translation_placeholders={"error": str(err)}) from err
    except ModbusError as err:
        raise HomeAssistantError(translation_domain=DOMAIN, translation_key="modbus_error",
                                 translation_placeholders={"error": str(err)}) from err
    for entry in entries:
        hass.config_entries.async_update_entry(
            entry, data={**entry.data, CONF_BAUDRATE: baudrate, CONF_PARITY: parity})
        state["coordinators"][entry.entry_id].mark_info_stale()
        await state["coordinators"][entry.entry_id].async_request_refresh()
