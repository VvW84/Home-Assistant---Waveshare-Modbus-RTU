"""Modbus RTU Relay (V3). Verify command values against the Waveshare wiki."""
from __future__ import annotations

from .common import check_channel
from .rtu import RTUClient

ON, OFF, TOGGLE = 0xFF00, 0x0000, 0xFF00  # toggle uses address 0x0100 + channel
ALL = 0xFF


def refresh(client: RTUClient, slave: int, variant: str = "current") -> dict:
    return {"relay": client.read_bits(slave, 1, 0, 8)}


def set_relay(client, slave, channel, on: bool):
    client.write_single(slave, 5, check_channel(channel), ON if on else OFF)


def toggle(client, slave, channel):
    client.write_single(slave, 5, 0x0100 + check_channel(channel), TOGGLE)


def flash(client, slave, channel, on: bool, delay_units: int):
    if not 1 <= int(delay_units) <= 32767:
        raise ValueError("Delay must be 1..32767 (100 ms units)")
    base = 0x0200 if on else 0x0400
    client.write_single(slave, 5, base + check_channel(channel), int(delay_units))


def all_relays(client, slave, command: str):
    if command == "on":
        client.write_single(slave, 5, ALL, ON)
    elif command == "off":
        client.write_single(slave, 5, ALL, OFF)
    elif command == "toggle":
        client.write_single(slave, 5, 0x0100 + ALL, TOGGLE)
    else:
        raise ValueError("Command must be on, off or toggle")


def write_mask(client, slave, mask: int):
    if not 0 <= int(mask) <= 255:
        raise ValueError("Mask must be 0..255")
    client.write_coils(slave, 0, [bool(mask & (1 << i)) for i in range(8)])


def toggle_mask(client, slave, mask: int):
    if not 0 <= int(mask) <= 255:
        raise ValueError("Mask must be 0..255")
    client.write_coils(slave, 0x0100, [bool(mask & (1 << i)) for i in range(8)])
