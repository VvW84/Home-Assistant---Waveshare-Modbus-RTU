"""Small synchronous Modbus RTU master. All calls are serialized by a bus lock."""
from __future__ import annotations

import logging
import threading
import time

import serial

_LOGGER = logging.getLogger(__name__)
READ_RETRIES = 2  # extra attempts for reads that time out or fail the CRC check
MIN_FRAME_GAP = 0.02  # seconds of bus silence between frames


class ModbusError(Exception):
    """Any communication or protocol error on the bus."""


class ModbusException(ModbusError):
    """The slave answered with a Modbus exception frame."""

    def __init__(self, function: int, code: int) -> None:
        super().__init__(f"Modbus exception {code} for function {function:02X}")
        self.function = function
        self.code = code


def crc16(data: bytes) -> int:
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA001 if crc & 1 else crc >> 1
    return crc


def with_crc(data: bytes) -> bytes:
    crc = crc16(data)
    return data + bytes((crc & 0xFF, crc >> 8))


class RTUClient:
    def __init__(self, port, baudrate=9600, parity="N", stopbits=1, timeout=1.0):
        self.port, self.baudrate, self.parity, self.stopbits, self.timeout = (
            port, baudrate, parity, stopbits, timeout)
        self.serial = None
        self.lock = threading.RLock()
        self._last_rx = 0.0

    # -- port handling ---------------------------------------------------
    def open(self):
        with self.lock:
            if self.serial is not None and self.serial.is_open:
                return
            try:
                self.serial = serial.Serial(
                    self.port, self.baudrate, bytesize=8, parity=self.parity,
                    stopbits=self.stopbits, timeout=self.timeout,
                    write_timeout=self.timeout)
            except (serial.SerialException, OSError, ValueError) as err:
                self.serial = None
                raise ModbusError(f"Cannot open {self.port}: {err}") from err

    def close(self):
        with self.lock:
            if self.serial is not None:
                try:
                    self.serial.close()
                except (serial.SerialException, OSError):
                    pass
            self.serial = None

    def reconfigure(self, baudrate=None, parity=None, stopbits=None):
        with self.lock:
            self.close()
            if baudrate is not None:
                self.baudrate = baudrate
            if parity is not None:
                self.parity = parity
            if stopbits is not None:
                self.stopbits = stopbits
            self.open()

    # -- framing ---------------------------------------------------------
    def _read_exact(self, count):
        data = bytearray()
        deadline = time.monotonic() + self.timeout
        while len(data) < count and time.monotonic() < deadline:
            chunk = self.serial.read(count - len(data))
            if chunk:
                data.extend(chunk)
        if len(data) != count:
            raise ModbusError(
                f"Timeout: expected {count} response bytes, received {len(data)}")
        return bytes(data)

    @staticmethod
    def _check_crc(frame):
        if len(frame) < 4 or crc16(frame[:-2]) != (frame[-2] | frame[-1] << 8):
            raise ModbusError("Invalid Modbus CRC")

    def request(self, slave, function, payload=b""):
        """One request; reads are retried on timeout/CRC errors, writes never are."""
        attempts = 1 + (READ_RETRIES if function in (1, 2, 3, 4) else 0)
        for attempt in range(1, attempts + 1):
            try:
                return self._request_once(slave, function, payload)
            except ModbusException:
                raise
            except ModbusError as err:
                if attempt == attempts:
                    raise
                _LOGGER.debug("Slave %s fc %02X attempt %d/%d failed: %s",
                              slave, function, attempt, attempts, err)
                time.sleep(0.05)

    def _request_once(self, slave, function, payload=b""):
        slave = int(slave)
        if not 1 <= slave <= 247:
            raise ValueError("Slave ID must be 1..247")
        with self.lock:
            self.open()
            try:
                # Keep >= 3.5 character times of silence between frames.
                gap = max(MIN_FRAME_GAP, 38.5 / self.baudrate + 0.002)
                wait = self._last_rx + gap - time.monotonic()
                if wait > 0:
                    time.sleep(wait)
                self.serial.reset_input_buffer()
                tx = with_crc(bytes((slave, function)) + payload)
                _LOGGER.debug("TX %s", tx.hex(" "))
                self.serial.write(tx)
                self.serial.flush()
                head = self._read_exact(3)
                if head[1] & 0x80:
                    frame = head + self._read_exact(2)
                    self._check_crc(frame)
                    self._validate_header(frame, slave, function & 0x7F, exc=True)
                    raise ModbusException(function, head[2])
                if function in (1, 2, 3, 4):
                    frame = head + self._read_exact(head[2] + 2)
                else:
                    frame = head + self._read_exact(5)
                self._last_rx = time.monotonic()
                _LOGGER.debug("RX %s", frame.hex(" "))
                self._check_crc(frame)
                self._validate_header(frame, slave, function)
                return frame
            except (serial.SerialException, OSError) as err:
                # Adapter unplugged or I/O failure: drop the handle so the next
                # call re-opens the port instead of failing forever.
                self.close()
                raise ModbusError(f"Serial error on {self.port}: {err}") from err

    @staticmethod
    def _validate_header(frame, slave, function, exc=False):
        if frame[0] != slave:
            raise ModbusError(f"Unexpected slave in response: {frame[0]}")
        got = frame[1] & 0x7F if exc else frame[1]
        if got != function:
            raise ModbusError(
                f"Unexpected function in response: {frame[1]:02X} (expected {function:02X})")

    @staticmethod
    def _check_echo(frame, payload, length):
        if frame[2:2 + length] != payload[:length]:
            raise ModbusError("Write acknowledgement does not match the request")

    # -- operations ------------------------------------------------------
    def read_bits(self, slave, function, address, count):
        r = self.request(slave, function, address.to_bytes(2, "big") + count.to_bytes(2, "big"))
        if r[2] != (count + 7) // 8:
            raise ModbusError("Unexpected byte count in response")
        return [bool(r[3 + i // 8] & (1 << (i % 8))) for i in range(count)]

    def read_registers(self, slave, function, address, count):
        r = self.request(slave, function, address.to_bytes(2, "big") + count.to_bytes(2, "big"))
        if r[2] != count * 2:
            raise ModbusError("Unexpected byte count in response")
        return [int.from_bytes(r[3 + i * 2:5 + i * 2], "big") for i in range(count)]

    def write_single(self, slave, function, address, value):
        payload = address.to_bytes(2, "big") + int(value).to_bytes(2, "big")
        r = self.request(slave, function, payload)
        self._check_echo(r, payload, 4)
        return r

    def write_multiple(self, slave, function, address, values):
        data = b"".join(int(v).to_bytes(2, "big") for v in values)
        payload = (address.to_bytes(2, "big") + len(values).to_bytes(2, "big")
                   + bytes((len(data),)) + data)
        r = self.request(slave, function, payload)
        self._check_echo(r, payload, 4)
        return r

    def write_coils(self, slave, address, values):
        packed = bytearray((len(values) + 7) // 8)
        for i, val in enumerate(values):
            if val:
                packed[i // 8] |= 1 << (i % 8)
        payload = (address.to_bytes(2, "big") + len(values).to_bytes(2, "big")
                   + bytes((len(packed),)) + bytes(packed))
        r = self.request(slave, 0x0F, payload)
        self._check_echo(r, payload, 4)
        return r
