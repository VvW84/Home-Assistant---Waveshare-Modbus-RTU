"""Modbus RTU Analog Input 8CH (A: current default, B: voltage default)."""
from __future__ import annotations

from .common import check_channel
from .rtu import RTUClient

REG_RANGE = 0x1000
RANGES = {
    "current": {0: "0-5 V", 1: "1-5 V", 2: "0-20 mA", 3: "4-20 mA", 4: "ADC raw"},
    "voltage": {0: "0-10 V", 1: "2-10 V", 2: "0-20 mA", 3: "4-20 mA", 4: "ADC raw"},
}


def refresh(client: RTUClient, slave: int, variant: str = "current") -> dict:
    return {
        "inputs_raw": client.read_registers(slave, 4, 0, 8),
        "input_ranges": client.read_registers(slave, 3, REG_RANGE, 8),
    }


def scale(raw: int, mode: int):
    """Raw register (mV / µA) to V / mA; mode 4 stays the raw ADC code."""
    return raw if mode == 4 else raw / 1000


def set_range(client, slave, channel, mode: int):
    if int(mode) not in range(5):
        raise ValueError("Range code must be 0..4")
    client.write_single(slave, 6, REG_RANGE + check_channel(channel), int(mode))


def set_ranges(client, slave, values):
    values = list(values)
    if len(values) != 8 or any(int(v) not in range(5) for v in values):
        raise ValueError("Provide exactly eight range codes (0..4)")
    client.write_multiple(slave, 0x10, REG_RANGE, values)
