"""Registers and helpers shared by all Waveshare Modbus RTU modules."""
from __future__ import annotations

import logging

from .rtu import ModbusError, RTUClient

_LOGGER = logging.getLogger(__name__)

BAUDRATES = [4800, 9600, 19200, 38400, 57600, 115200, 128000, 256000]
PARITIES = {"N": 0, "E": 1, "O": 2}
PARITY_NAMES = {v: k for k, v in PARITIES.items()}
MAX_ADDRESS = 247

REG_UART = 0x2000
REG_ADDRESS = 0x4000
REG_VERSION = 0x8000


def check_channel(channel: int) -> int:
    if not 0 <= int(channel) <= 7:
        raise ValueError("Channel must be 1..8")
    return int(channel)


def pack_uart(baudrate: int, parity: str) -> int:
    if baudrate not in BAUDRATES or parity not in PARITIES:
        raise ValueError("Unsupported UART setting")
    return (PARITIES[parity] << 8) | BAUDRATES.index(baudrate)


def read_info(client: RTUClient, slave: int) -> dict:
    """Static device information (read once, not on every poll)."""
    address = client.read_registers(slave, 3, REG_ADDRESS, 1)[0]
    version = client.read_registers(slave, 3, REG_VERSION, 1)[0]
    uart = client.read_registers(slave, 3, REG_UART, 1)[0]
    parity_code, baud_code = (uart >> 8) & 0xFF, uart & 0xFF
    return {
        "device_address": address,
        "firmware": f"{version // 100}.{version % 100:02d}",
        "uart_raw": uart,
        "parity": PARITY_NAMES.get(parity_code, f"Unknown ({parity_code})"),
        "baudrate": BAUDRATES[baud_code] if baud_code < len(BAUDRATES) else None,
    }


def set_address(client: RTUClient, slave: int, new: int) -> None:
    if not 1 <= int(new) <= MAX_ADDRESS:
        raise ValueError(f"Slave address must be between 1 and {MAX_ADDRESS}")
    try:
        client.write_single(slave, 6, REG_ADDRESS, int(new))
    except ModbusError:
        # The module may already answer from the new address: confirm there.
        try:
            confirmed = client.read_registers(int(new), 3, REG_ADDRESS, 1)[0] == int(new)
        except ModbusError:
            confirmed = False
        if not confirmed:
            raise


def _confirm_uart(client, slave, code) -> bool:
    try:
        return client.read_registers(slave, 3, REG_UART, 1)[0] == code
    except ModbusError:
        return False


def set_uart_for_devices(client: RTUClient, slaves: list[int], baudrate: int, parity: str) -> None:
    """Change UART settings of every module on the bus, with rollback.

    The whole sequence runs under the bus lock so polling cannot interleave.
    """
    new_code = pack_uart(baudrate, parity)
    old_baud, old_parity = client.baudrate, client.parity
    old_code = pack_uart(old_baud, old_parity)
    with client.lock:
        # Pre-flight: every module must answer before anything is changed.
        for slave in slaves:
            client.read_registers(slave, 3, REG_UART, 1)
        for slave in slaves:
            try:
                client.write_single(slave, 6, REG_UART, new_code)
            except ModbusError as err:  # acknowledgement may already use new settings
                _LOGGER.debug("UART write to %s not acknowledged at old settings: %s", slave, err)
        client.reconfigure(baudrate=baudrate, parity=parity)
        failed = [s for s in slaves if not _confirm_uart(client, s, new_code)]
        if not failed:
            return
        # Roll back: reach the modules that did switch, then return the host.
        for slave in slaves:
            if slave not in failed:
                try:
                    client.write_single(slave, 6, REG_UART, old_code)
                except ModbusError:
                    pass
        client.reconfigure(baudrate=old_baud, parity=old_parity)
        for slave in failed:
            try:
                client.write_single(slave, 6, REG_UART, old_code)
            except ModbusError:
                pass
        unreachable = [s for s in slaves if not _confirm_uart(client, s, old_code)]
        msg = f"Modules {failed} did not confirm the new UART settings; rolled back."
        if unreachable:
            msg += f" Still unreachable at the old settings: {unreachable}."
        raise ModbusError(msg)
