"""Per-model Waveshare Modbus RTU protocol implementations (no HA imports)."""
from . import analog_input, analog_output, relay, relay_d

PROTOCOLS = {
    "relay": relay,
    "relay_d": relay_d,
    "analog_output": analog_output,
    "analog_input": analog_input,
}
