"""Modbus RTU Relay (D): relays, digital inputs and per-channel relay modes."""
from __future__ import annotations

from .common import check_channel
from .relay import ALL, OFF, ON, flash, set_relay, write_mask  # noqa: F401
from .rtu import RTUClient

TOGGLE = 0x5500  # sent to the relay's own address
REG_MODE = 0x1000
MODES = {0: "Normal", 1: "Linkage", 2: "Toggle on pulse", 3: "Edge trigger"}


def refresh(client: RTUClient, slave: int, variant: str = "current") -> dict:
    return {
        "relay": client.read_bits(slave, 1, 0, 8),
        "inputs": client.read_bits(slave, 2, 0, 8),
        "relay_modes": client.read_registers(slave, 3, REG_MODE, 8),
    }


def toggle(client, slave, channel):
    client.write_single(slave, 5, check_channel(channel), TOGGLE)


def all_relays(client, slave, command: str):
    value = {"on": ON, "off": OFF, "toggle": TOGGLE}.get(command)
    if value is None:
        raise ValueError("Command must be on, off or toggle")
    client.write_single(slave, 5, ALL, value)


def set_mode(client, slave, channel, mode: int):
    if int(mode) not in MODES:
        raise ValueError("Mode must be 0..3")
    client.write_single(slave, 6, REG_MODE + check_channel(channel), int(mode))


def set_modes(client, slave, values):
    values = list(values)
    if len(values) != 8 or any(int(v) not in MODES for v in values):
        raise ValueError("Provide exactly eight mode values (0..3)")
    client.write_multiple(slave, 0x10, REG_MODE, values)
