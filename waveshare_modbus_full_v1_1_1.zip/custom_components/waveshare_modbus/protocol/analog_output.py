"""Modbus RTU Analog Output 8CH. Raw unit: µA (current/A) or mV (voltage/B)."""
from __future__ import annotations

from .common import check_channel
from .rtu import RTUClient


def max_raw(variant: str) -> int:
    return 10000 if variant == "voltage" else 20000


def refresh(client: RTUClient, slave: int, variant: str = "current") -> dict:
    return {"outputs": client.read_registers(slave, 3, 0, 8)}


def set_output(client, slave, channel, raw: int, variant: str = "current"):
    if not 0 <= int(raw) <= max_raw(variant):
        raise ValueError(f"Raw value must be 0..{max_raw(variant)}")
    client.write_single(slave, 6, check_channel(channel), int(raw))


def set_outputs(client, slave, values, variant: str = "current"):
    values = list(values)
    if len(values) != 8 or any(not 0 <= int(v) <= max_raw(variant) for v in values):
        raise ValueError(f"Provide exactly eight values between 0 and {max_raw(variant)}")
    client.write_multiple(slave, 0x10, 0, values)
