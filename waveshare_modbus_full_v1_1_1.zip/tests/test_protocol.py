"""Protocol tests against an in-memory Modbus RTU slave emulator (no HA, no hardware)."""
import sys, time, types, importlib, pathlib

class SerialException(Exception): pass
BUS = {}   # shared emulator state

class FakeSerial:
    def __init__(self, port, baudrate, bytesize=8, parity="N", stopbits=1, timeout=1, write_timeout=1):
        if BUS.get("missing"): raise SerialException("no such port")
        self.baud, self.parity, self.timeout, self.is_open = baudrate, parity, timeout, True
        self.rx = bytearray()
    def close(self): self.is_open = False
    def reset_input_buffer(self): self.rx.clear()
    def flush(self): pass
    def write(self, frame):
        if BUS.get("unplug"): raise SerialException("device disconnected")
        reply = BUS["emu"].handle(bytes(frame), self.baud, self.parity)
        if reply: self.rx.extend(reply)
    def read(self, n):
        out = bytes(self.rx[:n]); del self.rx[:n]
        if not out: time.sleep(min(self.timeout, 0.02))
        return out

sys.modules["serial"] = types.SimpleNamespace(Serial=FakeSerial, SerialException=SerialException)
sys.path.insert(0, str(pathlib.Path(__file__).parents[1] / "custom_components" / "waveshare_modbus"))
import protocol
from protocol import common, rtu, relay, relay_d, analog_input, analog_output
from protocol.rtu import RTUClient, ModbusError, ModbusException, with_crc, crc16

class Slave:
    def __init__(self, addr, baud=9600, parity="N", apply_uart="now"):
        self.addr, self.baud, self.parity, self.apply_uart = addr, baud, parity, apply_uart
        self.pending = None
        self.coils=[False]*8; self.di=[True,False]*4
        self.regs={0x4000:addr, 0x8000:200, 0x2000:0, 0x1000:0}
        self.regs.update({i:0 for i in range(8)}); self.in_regs={i:1000*(i+1) for i in range(8)}
        self.regs.update({0x1000+i:0 for i in range(8)})
        self.regs[0x2000]=common.pack_uart(baud, parity)
        self.nak_writes=False

class Emu:
    def __init__(self, *slaves): self.slaves={s.addr:s for s in slaves}; self.log=[]
    def handle(self, frame, baud, parity):
        if crc16(frame[:-2]) != (frame[-2] | frame[-1]<<8): return b""
        a, fc, body = frame[0], frame[1], frame[2:-2]
        s = self.slaves.get(a)
        if not s or (baud, parity) != (s.baud, s.parity): return b""
        def exc(code): return with_crc(bytes((a, fc|0x80, code)))
        adr = int.from_bytes(body[:2],"big"); val = int.from_bytes(body[2:4],"big")
        if fc in (1,2):
            bits = s.coils if fc==1 else s.di
            if adr+val > 8: return exc(2)
            b = bytearray((val+7)//8)
            for i in range(val):
                if bits[adr+i]: b[i//8] |= 1<<(i%8)
            return with_crc(bytes((a,fc,len(b)))+bytes(b))
        if fc in (3,4):
            src = s.regs if fc==3 else s.in_regs
            if any((adr+i) not in src for i in range(val)): return exc(2)
            return with_crc(bytes((a,fc,val*2))+b"".join(src[adr+i].to_bytes(2,"big") for i in range(val)))
        if fc in (5,6):
            if fc==5:
                if s.nak_writes or adr not in range(8) and adr not in (0xFF,0x1FF) and adr>>8 not in (1,2,4): return exc(2)
                if adr < 8: s.coils[adr] = (val==0xFF00) if val in (0,0xFF00) else (not s.coils[adr] if val==0x5500 else s.coils[adr])
            else:
                if s.nak_writes or adr not in s.regs: return exc(2)
                if adr==0x2000:
                    s.regs[adr]=val
                    new=(common.PARITY_NAMES[val>>8], common.BAUDRATES[val&0xFF])
                    if s.apply_uart=="now":
                        s.parity, s.baud = new; self.log.append(("applied",a)); return with_crc(frame[:6]) if False else with_crc(frame[:-2]) if False else self._ack_new(frame, s, new)
                    return with_crc(frame[:-2])
                if adr==0x4000:
                    s.regs[adr]=val; self.slaves.pop(a); s.addr=val; self.slaves[val]=s
                    return with_crc(bytes((val,))+frame[1:-2])   # acks from the NEW address
                s.regs[adr]=val
            return with_crc(frame[:-2])
        if fc==0x10:
            cnt=val
            for i in range(cnt): s.regs[adr+i]=int.from_bytes(body[5+2*i:7+2*i],"big")
            return with_crc(bytes((a,fc))+body[:4])
        if fc==0x0F:
            cnt=val
            for i in range(cnt): s.coils[adr+i]=bool(body[5+i//8]&(1<<(i%8)))
            return with_crc(bytes((a,fc))+body[:4])
        return exc(1)
    def _ack_new(self, frame, s, new): return with_crc(frame[:-2])  # ack sent at old settings, then applied

def fresh(*slaves, **kw):
    BUS.clear(); BUS["emu"]=Emu(*slaves); c=RTUClient("/dev/x", timeout=0.2, **kw); return c

passed=0
def check(name, cond):
    global passed
    print(("PASS " if cond else "FAIL ")+name); passed += bool(cond)
    if not cond: raise SystemExit(1)

# --- read paths per model --------------------------------------------------
c=fresh(Slave(1)); 
check("relay refresh", relay.refresh(c,1)["relay"]==[False]*8)
check("relay_d refresh", set(relay_d.refresh(c,1))=={"relay","inputs","relay_modes"})
check("analog_input refresh", analog_input.refresh(c,1)["inputs_raw"][2]==3000)
check("analog_output refresh", len(analog_output.refresh(c,1)["outputs"])==8)
info=common.read_info(c,1); check("info", info["firmware"]=="2.00" and info["baudrate"]==9600 and info["parity"]=="N")

# --- writes / commands ----------------------------------------------------
relay.set_relay(c,1,3,True); check("set_relay", relay.refresh(c,1)["relay"][3] is True)
relay_d.toggle(c,1,3); check("relay_d toggle", relay.refresh(c,1)["relay"][3] is False)
relay.write_mask(c,1,0b101); check("write_mask", relay.refresh(c,1)["relay"][:3]==[True,False,True])
relay_d.set_modes(c,1,[1,2,3,0,0,0,0,0]); check("set_modes", relay_d.refresh(c,1)["relay_modes"][:3]==[1,2,3])
analog_output.set_output(c,1,2,5000,"current"); check("AO set", analog_output.refresh(c,1)["outputs"][2]==5000)
for bad in (lambda: analog_output.set_output(c,1,2,10001,"voltage"), lambda: analog_input.set_range(c,1,0,5),
            lambda: relay.set_relay(c,1,8,True), lambda: analog_output.set_outputs(c,1,[0]*7)):
    try: bad(); ok=False
    except ValueError: ok=True
    check("validation rejects bad value", ok)

# --- error handling (previously broken) -----------------------------------
c.serial and None
s=BUS["emu"].slaves[1]; s.nak_writes=True; t=time.time()
try: relay.set_relay(c,1,0,True); got=None
except ModbusException as e: got=e
check("write exception reported as ModbusException (code 2), fast", got is not None and got.code==2 and time.time()-t<0.15)
s.nak_writes=False
try: c.read_registers(1,3,0x7777,1); got=None
except ModbusException as e: got=e
check("read exception reported", got is not None and got.code==2)
BUS["emu"].slaves[1].regs  # noqa
orig=BUS["emu"].handle
BUS["emu"].handle=lambda f,b,p: with_crc(bytes([1,4,2,0x12,0x34]))      # wrong function code
try: c.read_registers(1,3,0,1); rej=False
except ModbusError: rej=True
check("wrong function code rejected", rej)
BUS["emu"].handle=lambda f,b,p: with_crc(bytes([1,6])+f[2:4]+b"\x00\x09")     # wrong echo
try: c.write_single(1,6,0x1000,3); rej=False
except ModbusError: rej=True
check("wrong write echo rejected", rej)
BUS["emu"].handle=orig
try: c.request(0,3,b"\0\0\0\1"); rej=False
except ValueError: rej=True
check("slave 0 / >247 rejected", rej)

# --- unplugged adapter recovers -------------------------------------------
BUS["unplug"]=True
try: c.read_registers(1,3,0x4000,1); e=None
except ModbusError as err: e=err
check("unplug -> ModbusError and handle dropped", e is not None and c.serial is None)
BUS["unplug"]=False
check("reopens after replug", c.read_registers(1,3,0x4000,1)==[1])
BUS["missing"]=True; c.close()
try: c.open(); e=None
except ModbusError as err: e=err
check("open failure -> ModbusError (not SerialException)", e is not None); BUS["missing"]=False

# --- address change; device acks from new address -------------------------
c=fresh(Slave(1), Slave(2))
common.set_address(c,1,5); check("address change confirmed via new address", c.read_registers(5,3,0x4000,1)==[5])
try: common.set_address(c,5,248); rej=False
except ValueError: rej=True
check("address >247 rejected", rej)

# --- UART change: success, immediate apply, 2 modules ---------------------
c=fresh(Slave(1), Slave(2))
common.set_uart_for_devices(c,[1,2],19200,"E")
check("uart change: host + both modules on new settings", (c.baudrate,c.parity)==(19200,"E")
      and all(common._confirm_uart(c,a,common.pack_uart(19200,"E")) for a in (1,2)))
# --- UART change: pre-flight aborts when one module is offline ------------
c=fresh(Slave(1))
try: common.set_uart_for_devices(c,[1,2],19200,"N"); aborted=False
except ModbusError: aborted=True
check("offline module -> abort before changing anything", aborted and BUS["emu"].slaves[1].baud==9600 and c.baudrate==9600)
# --- UART change: one module never switches -> rollback --------------------
class Stubborn(Slave):
    pass
c=fresh(Slave(1), Slave(2, apply_uart="never"))   # slave 2 stores value but keeps old line settings
try: common.set_uart_for_devices(c,[1,2],38400,"N"); rb=None
except ModbusError as err: rb=str(err)
s1,s2=BUS["emu"].slaves[1],BUS["emu"].slaves[2]
check("partial failure rolled back (host+both modules at 9600/N)",
      rb is not None and (c.baudrate,c.parity)==(9600,"N") and (s1.baud,s2.baud)==(9600,9600)
      and s1.regs[0x2000]==s2.regs[0x2000]==common.pack_uart(9600,"N") and "unreachable" not in rb)
# --- transient glitches are retried; persistent ones still fail -------------
c=fresh(Slave(1)); real=BUS["emu"].handle; drops={"n":1}
def flaky(f,b,p):
    if drops["n"]>0: drops["n"]-=1; return b""
    return real(f,b,p)
BUS["emu"].handle=flaky
check("single dropped reply is retried transparently", c.read_registers(1,3,0x4000,1)==[1])
drops["n"]=1
try: relay.set_relay(c,1,0,True); w=False
except ModbusError: w=True
check("writes are NOT retried (no double toggle)", w)
drops["n"]=99
try: c.read_registers(1,3,0x4000,1); f=False
except ModbusError: f=True
check("persistent failure still raises", f)
print(f"\n{passed} checks passed")
